var APPLICATION_ID = "dj0zaiZpPVFUZVNpS09xdzNvMiZzPWNvbnN1bWVyc2VjcmV0Jng9Mjk-";

var Main = {
  init: function() {
    Main.light = 10;
    Main.setupAmbientLightSensor();
    Main.setupGeolocationSensor();
  },
  setupGeolocationSensor: function() {
    var watchID = navigator.geolocation.watchPosition(function(position) {
      Main.drawImage(position.coords.latitude, position.coords.longitude)
    });

    //dammy
//    setInterval(Main.drawImage, 3000, 35.66633, 139.73103);
  },
  setupAmbientLightSensor: function() {
    window.addEventListener("devicelight", function(e) {
      Main.light = e.value;
      $("#ambient").text("ambient light:"+e.value);
    });
  },

  drawImage: function(latitude, longitude) {
    console.log("latitude:"+latitude+" longitude:"+longitude);
    $("#geolocation").text(latitude+", "+longitude);

    var documentObject = $(document);
    var width = documentObject.width();
    var height = documentObject.height();

    var url = "http://map.olp.yahooapis.jp/OpenLocalPlatform/V1/static?z=19&appid="+APPLICATION_ID+"&lat="+latitude+"&lon="+longitude+"&width="+width+"&height="+height;
//    var url = "static.png";
    console.log(url);

    var image = new Image();
    image.src = url;
    image.onload = function() {
      var canvas = document.getElementById("map-canvas");
      canvas.setAttribute("width", width);
      canvas.setAttribute("height", height);
      var context = canvas.getContext("2d");
      context.drawImage(image, 0, 0);
      /*
      if (Main.light < 50) {
        var imageData = context.getImageData(0, 0, image.width, image.height);
        var data = imageData.data;
        for (var y = 0; y < height; y++) {
          for (var x = 0; x < width; x++) {
            var pos = y * width + x;
            var index = pos*4;
            var red = 255-data[index+0];
            var green = 255-data[index+1];
            var blue = 255-data[index+2];
            var rgb = 'rgb(' + red + ',' + green + ',' + blue + ')';
            context.fillStyle = rgb;
            context.fillRect(x, y, 1, 1);
          }
        }
      }
      */
    }
  }
}

$(document).ready(function() {
  Main.init();
});