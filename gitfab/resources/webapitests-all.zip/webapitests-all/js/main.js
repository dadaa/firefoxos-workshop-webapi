var Main = {
  init: function() {
    Main.setupAmbientLightSensor();
    Main.setupGeolocationSensor();
    Main.setupProximitySensor();

    Main.setupAlarm();
    Main.setupNotification();
  },

  setupAmbientLightSensor: function() {
    window.addEventListener("devicelight", function(e) {
      console.log("devicelight:"+e.value);
      $("#ambient-light").text(e.value);
    });
  },

  setupGeolocationSensor: function() {
    var watchID = navigator.geolocation.watchPosition(function(position) {
      console.log("latitude:"+position.coords.latitude+" longitude:"+position.coords.longitude);
      var lonlat = position.coords.latitude+", "+position.coords.longitude;
      $("#geolocation").text(lonlat);
    });
  },

  setupProximitySensor: function() {
    window.addEventListener("userproximity", function(e) {
      console.log("userproximity:"+e.near);
      $("#proximity").text(e.near);
    });
  },

  setupAlarm: function() {
    var date = new Date();
    var now = date.getTime();
    date.setTime(now+5000);
    navigator.mozAlarms.add(date, "ignoreTimezone", {"message":"5 seconds"});  
  },

  setupNotification: function() {
    var notification = navigator.mozNotification.createNotification("please click", "thanks");
    notification.show();
  },

}

$(document).ready(function() {
  Main.init();
});